public class Main
{
	public static void main(String[] args) {
	     int x,y;
	    x=22;
	    y=22;
		System.out.println(x=y);
		System.out.println(x+=y);
		System.out.println(x-=y);
		System.out.println(x*=y);
		System.out.println(x/=y);
		System.out.println(x%=y);
	}
}